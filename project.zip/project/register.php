<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $firstname = $_POST['firstname'];
  $lastname = $_POST['lastname'];
  $username = $_POST['username'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $address = $_POST['address'];
  $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

  $sql = "INSERT INTO users (firstname, lastname, username, email, phone, address, password)
          VALUES (?, ?, ?, ?, ?, ?, ?)";

  $stmt = $conn->prepare($sql);
  $stmt->bind_param("sssssss", $firstname, $lastname, $username, $email, $phone, $address, $password);

  if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Registration successful!']);
  } else {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $stmt->error]);
  }
}
?>
