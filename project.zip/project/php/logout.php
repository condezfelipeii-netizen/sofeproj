<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/response.php';

// Since we're using stateless authentication, logout is handled client-side
// This endpoint exists for consistency and future session-based auth
sendResponse(true, 'Logout successful');
?>

