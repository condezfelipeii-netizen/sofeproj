<?php
session_start();

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/response.php';

// Google OAuth Configuration
define('GOOGLE_CLIENT_ID', 'YOUR_GOOGLE_CLIENT_ID');
define('GOOGLE_CLIENT_SECRET', 'YOUR_GOOGLE_CLIENT_SECRET');
define('GOOGLE_REDIRECT_URI', 'http://localhost:8080/jessie-cane-api/php/google-callback.php');

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

// Check if Google API client is available
if (!class_exists('Google_Client')) {
    sendError('Google API client not installed. Please install via Composer: composer require google/apiclient', 500);
}

$client = new Google_Client();
$client->setClientId(GOOGLE_CLIENT_ID);
$client->setClientSecret(GOOGLE_CLIENT_SECRET);
$client->setRedirectUri(GOOGLE_REDIRECT_URI);
$client->addScope('email');
$client->addScope('profile');

// Generate and return auth URL
$authUrl = $client->createAuthUrl();

sendResponse(true, 'Google auth URL generated', ['auth_url' => $authUrl]);
?>

