<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/response.php';

$orderId = $_GET['order_id'] ?? null;
$invoiceId = $_GET['invoice_id'] ?? null;

if (!$orderId && !$invoiceId) {
    sendError('Order ID or Invoice ID is required');
}

$database = new Database();
$db = $database->getConnection();

if ($invoiceId) {
    $query = "SELECT p.*, o.order_id as order_ref FROM payments p 
              JOIN orders o ON p.order_id = o.id 
              WHERE p.xendit_id = :invoice_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':invoice_id', $invoiceId);
} else {
    $query = "SELECT p.*, o.order_id as order_ref FROM payments p 
              JOIN orders o ON p.order_id = o.id 
              WHERE o.order_id = :order_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':order_id', $orderId);
}

$stmt->execute();
$payment = $stmt->fetch();

if (!$payment) {
    sendError('Payment not found', 404);
}

sendResponse(true, 'Payment status retrieved', $payment);
?>

