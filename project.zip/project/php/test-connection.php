<?php
/**
 * Quick test file to verify backend setup
 * Visit: http://localhost:8080/jessie-cane-api/php/test-connection.php
 */

echo "<h1>Jessie Cane API - Connection Test</h1>";

// Test 1: Database Connection
echo "<h2>Test 1: Database Connection</h2>";
require_once __DIR__ . '/database.php';

try {
    $database = new Database();
    $db = $database->getConnection();
    
    if ($db) {
        echo "<p style='color: green;'>✓ Database connection successful!</p>";
        
        // Test 2: Check if tables exist
        echo "<h2>Test 2: Database Tables</h2>";
        $tables = ['users', 'products', 'orders', 'order_items', 'payments', 'event_inquiries'];
        
        foreach ($tables as $table) {
            $query = "SHOW TABLES LIKE '$table'";
            $stmt = $db->query($query);
            if ($stmt->rowCount() > 0) {
                echo "<p style='color: green;'>✓ Table '$table' exists</p>";
            } else {
                echo "<p style='color: red;'>✗ Table '$table' NOT found</p>";
            }
        }
        
        // Test 3: Check if admin user exists
        echo "<h2>Test 3: Default Admin User</h2>";
        $query = "SELECT id, name, email, role FROM users WHERE username = 'admin'";
        $stmt = $db->query($query);
        $admin = $stmt->fetch();
        
        if ($admin) {
            echo "<p style='color: green;'>✓ Admin user exists</p>";
            echo "<pre>Username: admin\nEmail: {$admin['email']}\nRole: {$admin['role']}</pre>";
        } else {
            echo "<p style='color: orange;'>⚠ Admin user not found. Import database-setup.sql</p>";
        }
        
        // Test 4: Check products count
        echo "<h2>Test 4: Products</h2>";
        $query = "SELECT COUNT(*) as count FROM products";
        $stmt = $db->query($query);
        $result = $stmt->fetch();
        $count = $result['count'];
        
        if ($count > 0) {
            echo "<p style='color: green;'>✓ Found $count products in database</p>";
        } else {
            echo "<p style='color: orange;'>⚠ No products found. Import database-setup.sql</p>";
        }
        
    } else {
        echo "<p style='color: red;'>✗ Database connection failed!</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Error: " . $e->getMessage() . "</p>";
}

// Test 5: PHP Extensions
echo "<h2>Test 5: PHP Extensions</h2>";
$extensions = ['pdo', 'pdo_mysql', 'openssl', 'curl', 'mbstring', 'json'];

foreach ($extensions as $ext) {
    if (extension_loaded($ext)) {
        echo "<p style='color: green;'>✓ $ext extension loaded</p>";
    } else {
        echo "<p style='color: red;'>✗ $ext extension NOT loaded</p>";
    }
}

// Test 6: API Endpoints Status
echo "<h2>Test 6: API Endpoints</h2>";
$endpoints = [
    'GET /php/get-all.php',
    'POST /php/login.php',
    'GET /php/profile.php',
];

foreach ($endpoints as $endpoint) {
    echo "<p style='color: blue;'>→ $endpoint</p>";
}

echo "<hr>";
echo "<h2>Quick Test Links</h2>";
echo "<ul>";
echo "<li><a href='get-all.php' target='_blank'>Test Products API</a></li>";
echo "<li><a href='http://localhost:8080/phpmyadmin' target='_blank'>Open phpMyAdmin</a></li>";
echo "</ul>";

echo "<hr>";
echo "<h2>Next Steps</h2>";
echo "<ol>";
echo "<li>If database connection failed, check XAMPP MySQL is running</li>";
echo "<li>If tables are missing, import database-setup.sql in phpMyAdmin</li>";
echo "<li>If extensions are missing, enable them in php.ini and restart Apache</li>";
echo "<li>Test login with: admin@gmail.com / admin123</li>";
echo "</ol>";
?>

