<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: PUT, POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/response.php';
require_once __DIR__ . '/auth-helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'PUT' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Method not allowed', 405);
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['id'])) {
    sendError('User ID is required');
}

$id = $data['id'];
$name = $data['name'] ?? null;
$username = $data['username'] ?? null;
$email = $data['email'] ?? null;
$phone = $data['phone'] ?? null;
$address = $data['address'] ?? null;
$password = $data['password'] ?? null;

$database = new Database();
$db = $database->getConnection();

// Check if user exists
$query = "SELECT * FROM users WHERE id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $id);
$stmt->execute();
$user = $stmt->fetch();

if (!$user) {
    sendError('User not found', 404);
}

// Validate email if provided
if ($email !== null && !validateEmail($email)) {
    sendError('Invalid email format');
}

// Check if username or email already exists (excluding current user)
if ($username !== null || $email !== null) {
    $checkQuery = "SELECT id FROM users WHERE (username = :username OR email = :email) AND id != :id";
    $checkStmt = $db->prepare($checkQuery);
    if ($username !== null) {
        $checkStmt->bindParam(':username', $username);
    } else {
        $checkStmt->bindParam(':username', $user['username']);
    }
    if ($email !== null) {
        $checkStmt->bindParam(':email', $email);
    } else {
        $checkStmt->bindParam(':email', $user['email']);
    }
    $checkStmt->bindParam(':id', $id);
    $checkStmt->execute();
    
    if ($checkStmt->fetch()) {
        sendError('Username or email already exists');
    }
}

// Build update query dynamically
$updateFields = [];
$params = [':id' => $id];

if ($name !== null) {
    $updateFields[] = 'name = :name';
    $params[':name'] = $name;
}
if ($username !== null) {
    $updateFields[] = 'username = :username';
    $params[':username'] = $username;
}
if ($email !== null) {
    $updateFields[] = 'email = :email';
    $params[':email'] = $email;
}
if ($phone !== null) {
    $updateFields[] = 'phone = :phone';
    $params[':phone'] = $phone;
}
if ($address !== null) {
    $updateFields[] = 'address = :address';
    $params[':address'] = $address;
}
if ($password !== null) {
    $updateFields[] = 'password = :password';
    $params[':password'] = hashPassword($password);
}

if (empty($updateFields)) {
    sendError('No fields to update');
}

$query = "UPDATE users SET " . implode(', ', $updateFields) . " WHERE id = :id";
$stmt = $db->prepare($query);

foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}

if ($stmt->execute()) {
    $query = "SELECT id, name, username, email, phone, address, role, created_at FROM users WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $user = $stmt->fetch();
    
    sendResponse(true, 'User updated successfully', $user);
} else {
    sendError('Failed to update user');
}
?>

