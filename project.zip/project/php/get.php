<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/response.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    sendError('Product ID is required');
}

$database = new Database();
$db = $database->getConnection();

$query = "SELECT * FROM products WHERE id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $id);
$stmt->execute();

$product = $stmt->fetch();

if (!$product) {
    sendError('Product not found', 404);
}

// Update image path to relative URL
if ($product['image'] && !str_starts_with($product['image'], 'http://') && !str_starts_with($product['image'], 'https://')) {
    $product['image'] = '../../assets/images/' . $product['image'];
}

sendResponse(true, 'Product retrieved successfully', $product);
?>

