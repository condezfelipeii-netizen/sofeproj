<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/response.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Method not allowed', 405);
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['name']) || !isset($data['price_regular']) || !isset($data['price_tall'])) {
    sendError('Name, price_regular, and price_tall are required');
}

$name = $data['name'];
$description = $data['description'] ?? '';
$image = $data['image'] ?? '';
$priceRegular = $data['price_regular'];
$priceTall = $data['price_tall'];

$database = new Database();
$db = $database->getConnection();

$query = "INSERT INTO products (name, description, image, price_regular, price_tall) 
          VALUES (:name, :description, :image, :price_regular, :price_tall)";
$stmt = $db->prepare($query);

$stmt->bindParam(':name', $name);
$stmt->bindParam(':description', $description);
$stmt->bindParam(':image', $image);
$stmt->bindParam(':price_regular', $priceRegular);
$stmt->bindParam(':price_tall', $priceTall);

if ($stmt->execute()) {
    $productId = $db->lastInsertId();
    
    $query = "SELECT * FROM products WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $productId);
    $stmt->execute();
    $product = $stmt->fetch();
    
    // Update image path to relative URL
    if ($product['image'] && !str_starts_with($product['image'], 'http://') && !str_starts_with($product['image'], 'https://')) {
        $product['image'] = '../../assets/images/' . $product['image'];
    }
    
    sendResponse(true, 'Product created successfully', $product);
} else {
    sendError('Failed to create product');
}
?>

