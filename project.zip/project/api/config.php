<?php
// API Configuration
define('BASE_URL', 'http://localhost:8080/project');
define('API_BASE_URL', BASE_URL . '/api/api');

// Database Configuration (can be moved to separate file if needed)
define('DB_HOST', 'localhost');
define('DB_NAME', 'jessie_cane_db');
define('DB_USER', 'root');
define('DB_PASS', '');

// Xendit Configuration
define('XENDIT_API_URL', 'https://api.xendit.co/v2/invoices');
define('XENDIT_SECRET_KEY', 'YOUR_XENDIT_SECRET_KEY_HERE');
define('XENDIT_WEBHOOK_TOKEN', 'YOUR_WEBHOOK_TOKEN_HERE');

// Google OAuth Configuration
define('GOOGLE_CLIENT_ID', 'YOUR_GOOGLE_CLIENT_ID');
define('GOOGLE_CLIENT_SECRET', 'YOUR_GOOGLE_CLIENT_SECRET');
define('GOOGLE_REDIRECT_URI', BASE_URL . '/api/api/auth/google-callback.php');
define('FRONTEND_DOMAIN', BASE_URL . '/public/customer');
?>

