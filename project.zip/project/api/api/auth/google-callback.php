<?php
session_start();

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/response.php';
require_once __DIR__ . '/../../utils/auth-helpers.php';

define('GOOGLE_CLIENT_ID', 'YOUR_GOOGLE_CLIENT_ID');
define('GOOGLE_CLIENT_SECRET', 'YOUR_GOOGLE_CLIENT_SECRET');
define('GOOGLE_REDIRECT_URI', 'http://localhost:8080/project/api/api/auth/google-callback.php');
define('FRONTEND_DOMAIN', 'http://localhost:8080/project/public/customer');

if (!isset($_GET['code'])) {
    header('Location: ' . FRONTEND_DOMAIN . '/customer_dashboard.html?auth=error');
    exit;
}

$code = $_GET['code'];

// Exchange code for token
$tokenUrl = 'https://oauth2.googleapis.com/token';
$tokenData = [
    'code' => $code,
    'client_id' => GOOGLE_CLIENT_ID,
    'client_secret' => GOOGLE_CLIENT_SECRET,
    'redirect_uri' => GOOGLE_REDIRECT_URI,
    'grant_type' => 'authorization_code'
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $tokenUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($tokenData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);

$tokenResponse = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200) {
    header('Location: ' . FRONTEND_DOMAIN . '/customer_dashboard.html?auth=error');
    exit;
}

$tokenData = json_decode($tokenResponse, true);
$accessToken = $tokenData['access_token'] ?? null;

if (!$accessToken) {
    header('Location: ' . FRONTEND_DOMAIN . '/customer_dashboard.html?auth=error');
    exit;
}

// Get user info from Google
$userInfoUrl = 'https://www.googleapis.com/oauth2/v2/userinfo';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $userInfoUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $accessToken]);

$userInfoResponse = curl_exec($ch);
curl_close($ch);

$userInfo = json_decode($userInfoResponse, true);

if (!$userInfo || !isset($userInfo['email'])) {
    header('Location: ' . FRONTEND_DOMAIN . '/customer_dashboard.html?auth=error');
    exit;
}

// Check if user exists
$database = new Database();
$db = $database->getConnection();

$query = "SELECT * FROM users WHERE google_id = :google_id OR email = :email";
$stmt = $db->prepare($query);
$stmt->bindParam(':google_id', $userInfo['id']);
$stmt->bindParam(':email', $userInfo['email']);
$stmt->execute();
$user = $stmt->fetch();

if (!$user) {
    // Create new user
    $name = $userInfo['name'] ?? $userInfo['email'];
    $username = strtolower(str_replace(' ', '_', $name)) . '_' . substr($userInfo['id'], 0, 8);
    
    $query = "INSERT INTO users (name, username, email, google_id, role, password) 
              VALUES (:name, :username, :email, :google_id, 'customer', :password)";
    $stmt = $db->prepare($query);
    $password = hashPassword(uniqid()); // Random password for Google users
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email', $userInfo['email']);
    $stmt->bindParam(':google_id', $userInfo['id']);
    $stmt->bindParam(':password', $password);
    $stmt->execute();
    
    $userId = $db->lastInsertId();
    $user = ['id' => $userId, 'name' => $name, 'email' => $userInfo['email'], 'role' => 'customer'];
} else {
    // Update google_id if not set
    if (!$user['google_id']) {
        $updateQuery = "UPDATE users SET google_id = :google_id WHERE id = :id";
        $updateStmt = $db->prepare($updateQuery);
        $updateStmt->bindParam(':google_id', $userInfo['id']);
        $updateStmt->bindParam(':id', $user['id']);
        $updateStmt->execute();
    }
}

// Generate token and redirect
$token = generateToken($user['id'], $user['role'] ?? 'customer');

header('Location: ' . FRONTEND_DOMAIN . '/customer_dashboard.html?auth=success&token=' . urlencode($token) . '&user=' . urlencode(json_encode($user)));
exit;
?>

