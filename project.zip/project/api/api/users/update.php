<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: PUT, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/response.php';
require_once __DIR__ . '/../../utils/auth-helpers.php';

$user = requireAuth();

$data = json_decode(file_get_contents('php://input'), true);

$name = isset($data['name']) ? trim($data['name']) : null;
$phone = isset($data['phone']) ? trim($data['phone']) : null;
$address = isset($data['address']) ? trim($data['address']) : null;
$password = $data['password'] ?? null;

$database = new Database();
$db = $database->getConnection();

$updateFields = [];
$params = [':id' => $user['id']];

if ($name !== null) {
    $updateFields[] = "name = :name";
    $params[':name'] = $name;
}

if ($phone !== null) {
    $updateFields[] = "phone = :phone";
    $params[':phone'] = $phone;
}

if ($address !== null) {
    $updateFields[] = "address = :address";
    $params[':address'] = $address;
}

if ($password !== null && strlen($password) >= 6) {
    $updateFields[] = "password = :password";
    $params[':password'] = hashPassword($password);
}

if (empty($updateFields)) {
    sendError('No fields to update');
}

$query = "UPDATE users SET " . implode(', ', $updateFields) . " WHERE id = :id";
$stmt = $db->prepare($query);

foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}

if ($stmt->execute()) {
    $query = "SELECT id, name, username, email, role, phone, address FROM users WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $user['id']);
    $stmt->execute();
    $updatedUser = $stmt->fetch();
    
    sendResponse(true, 'Profile updated successfully', $updatedUser);
} else {
    sendError('Failed to update profile');
}
?>

