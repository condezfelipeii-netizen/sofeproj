<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/response.php';
require_once __DIR__ . '/../../utils/auth-helpers.php';

$user = getAuthUser();

if (!$user) {
    // Allow getting profile by ID for admin users
    $id = $_GET['id'] ?? null;
    $currentUser = getAuthUser();
    
    if ($id && $currentUser && $currentUser['role'] === 'admin') {
        $database = new Database();
        $db = $database->getConnection();
        
        $query = "SELECT id, name, username, email, role, phone, address, created_at FROM users WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $user = $stmt->fetch();
        
        if (!$user) {
            sendError('User not found', 404);
        }
        
        sendResponse(true, 'User profile retrieved successfully', $user);
    } else {
        sendError('Authentication required', 401);
    }
} else {
    sendResponse(true, 'Profile retrieved successfully', $user);
}
?>

