-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2025 at 10:23 AM
-- Server version: 8.0.44
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_ordering_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('superadmin','manager') DEFAULT 'manager'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `branch_id` int NOT NULL,
  `branch_name` varchar(100) NOT NULL,
  `location` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cashiers`
--

CREATE TABLE `cashiers` (
  `cashier_id` int NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `branch_id` int DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `address` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `drinks`
--

CREATE TABLE `drinks` (
  `drink_id` int NOT NULL,
  `drink_name` varchar(100) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `price` decimal(6,2) NOT NULL,
  `availability` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int NOT NULL,
  `customer_id` int DEFAULT NULL,
  `branch_id` int DEFAULT NULL,
  `cashier_id` int DEFAULT NULL,
  `order_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `total_amount` decimal(8,2) NOT NULL,
  `payment_method` enum('cash','gcash','card') NOT NULL,
  `status` enum('pending','preparing','completed','cancelled') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `item_id` int NOT NULL,
  `order_id` int DEFAULT NULL,
  `drink_id` int DEFAULT NULL,
  `quantity` int NOT NULL,
  `subtotal` decimal(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `receipts`
--

CREATE TABLE `receipts` (
  `receipt_id` int NOT NULL,
  `order_id` int DEFAULT NULL,
  `payment_method` enum('cash','gcash','card') NOT NULL,
  `payment_status` enum('paid','unpaid','refunded') DEFAULT 'paid',
  `gcash_reference` varchar(50) DEFAULT NULL,
  `amount_paid` decimal(8,2) NOT NULL,
  `date_issued` datetime DEFAULT CURRENT_TIMESTAMP,
  `cashier_id` int DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales_annual`
--

CREATE TABLE `sales_annual` (
  `annual_id` int NOT NULL,
  `year` year NOT NULL,
  `branch_id` int DEFAULT NULL,
  `total_orders` int DEFAULT '0',
  `total_sales` decimal(12,2) DEFAULT '0.00',
  `total_gcash` decimal(12,2) DEFAULT '0.00',
  `total_cash` decimal(12,2) DEFAULT '0.00',
  `total_card` decimal(12,2) DEFAULT '0.00',
  `generated_by` int DEFAULT NULL,
  `generated_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales_daily`
--

CREATE TABLE `sales_daily` (
  `daily_id` int NOT NULL,
  `report_date` date NOT NULL,
  `branch_id` int DEFAULT NULL,
  `total_orders` int DEFAULT '0',
  `total_sales` decimal(10,2) DEFAULT '0.00',
  `total_gcash` decimal(10,2) DEFAULT '0.00',
  `total_cash` decimal(10,2) DEFAULT '0.00',
  `total_card` decimal(10,2) DEFAULT '0.00',
  `generated_by` int DEFAULT NULL,
  `generated_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales_monthly`
--

CREATE TABLE `sales_monthly` (
  `monthly_id` int NOT NULL,
  `month` varchar(20) NOT NULL,
  `branch_id` int DEFAULT NULL,
  `total_orders` int DEFAULT '0',
  `total_sales` decimal(10,2) DEFAULT '0.00',
  `total_gcash` decimal(10,2) DEFAULT '0.00',
  `total_cash` decimal(10,2) DEFAULT '0.00',
  `total_card` decimal(10,2) DEFAULT '0.00',
  `generated_by` int DEFAULT NULL,
  `generated_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales_weekly`
--

CREATE TABLE `sales_weekly` (
  `weekly_id` int NOT NULL,
  `week_start` date NOT NULL,
  `week_end` date NOT NULL,
  `branch_id` int DEFAULT NULL,
  `total_orders` int DEFAULT '0',
  `total_sales` decimal(10,2) DEFAULT '0.00',
  `total_gcash` decimal(10,2) DEFAULT '0.00',
  `total_cash` decimal(10,2) DEFAULT '0.00',
  `total_card` decimal(10,2) DEFAULT '0.00',
  `generated_by` int DEFAULT NULL,
  `generated_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `cashiers`
--
ALTER TABLE `cashiers`
  ADD PRIMARY KEY (`cashier_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `drinks`
--
ALTER TABLE `drinks`
  ADD PRIMARY KEY (`drink_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `cashier_id` (`cashier_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `drink_id` (`drink_id`);

--
-- Indexes for table `receipts`
--
ALTER TABLE `receipts`
  ADD PRIMARY KEY (`receipt_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `cashier_id` (`cashier_id`);

--
-- Indexes for table `sales_annual`
--
ALTER TABLE `sales_annual`
  ADD PRIMARY KEY (`annual_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `generated_by` (`generated_by`);

--
-- Indexes for table `sales_daily`
--
ALTER TABLE `sales_daily`
  ADD PRIMARY KEY (`daily_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `generated_by` (`generated_by`);

--
-- Indexes for table `sales_monthly`
--
ALTER TABLE `sales_monthly`
  ADD PRIMARY KEY (`monthly_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `generated_by` (`generated_by`);

--
-- Indexes for table `sales_weekly`
--
ALTER TABLE `sales_weekly`
  ADD PRIMARY KEY (`weekly_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `generated_by` (`generated_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `branch_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cashiers`
--
ALTER TABLE `cashiers`
  MODIFY `cashier_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `drinks`
--
ALTER TABLE `drinks`
  MODIFY `drink_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `item_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `receipts`
--
ALTER TABLE `receipts`
  MODIFY `receipt_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales_annual`
--
ALTER TABLE `sales_annual`
  MODIFY `annual_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales_daily`
--
ALTER TABLE `sales_daily`
  MODIFY `daily_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales_monthly`
--
ALTER TABLE `sales_monthly`
  MODIFY `monthly_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales_weekly`
--
ALTER TABLE `sales_weekly`
  MODIFY `weekly_id` int NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cashiers`
--
ALTER TABLE `cashiers`
  ADD CONSTRAINT `cashiers_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`),
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`cashier_id`) REFERENCES `cashiers` (`cashier_id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`drink_id`) REFERENCES `drinks` (`drink_id`);

--
-- Constraints for table `receipts`
--
ALTER TABLE `receipts`
  ADD CONSTRAINT `receipts_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `receipts_ibfk_2` FOREIGN KEY (`cashier_id`) REFERENCES `cashiers` (`cashier_id`);

--
-- Constraints for table `sales_annual`
--
ALTER TABLE `sales_annual`
  ADD CONSTRAINT `sales_annual_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`),
  ADD CONSTRAINT `sales_annual_ibfk_2` FOREIGN KEY (`generated_by`) REFERENCES `admins` (`admin_id`);

--
-- Constraints for table `sales_daily`
--
ALTER TABLE `sales_daily`
  ADD CONSTRAINT `sales_daily_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`),
  ADD CONSTRAINT `sales_daily_ibfk_2` FOREIGN KEY (`generated_by`) REFERENCES `admins` (`admin_id`);

--
-- Constraints for table `sales_monthly`
--
ALTER TABLE `sales_monthly`
  ADD CONSTRAINT `sales_monthly_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`),
  ADD CONSTRAINT `sales_monthly_ibfk_2` FOREIGN KEY (`generated_by`) REFERENCES `admins` (`admin_id`);

--
-- Constraints for table `sales_weekly`
--
ALTER TABLE `sales_weekly`
  ADD CONSTRAINT `sales_weekly_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`),
  ADD CONSTRAINT `sales_weekly_ibfk_2` FOREIGN KEY (`generated_by`) REFERENCES `admins` (`admin_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
