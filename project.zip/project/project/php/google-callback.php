<?php
session_start();

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/response.php';

define('GOOGLE_CLIENT_ID', 'YOUR_GOOGLE_CLIENT_ID');
define('GOOGLE_CLIENT_SECRET', 'YOUR_GOOGLE_CLIENT_SECRET');
define('GOOGLE_REDIRECT_URI', 'http://localhost:8080/jessie-cane-api/php/google-callback.php');
define('FRONTEND_DOMAIN', 'http://localhost:8080/Project-sa-SOFE-main/public/customer');

// Check if Google API client is available
if (!class_exists('Google_Client')) {
    header('Location: ' . FRONTEND_DOMAIN . '/customer_dashboard.html?auth=error');
    exit;
}

$client = new Google_Client();
$client->setClientId(GOOGLE_CLIENT_ID);
$client->setClientSecret(GOOGLE_CLIENT_SECRET);
$client->setRedirectUri(GOOGLE_REDIRECT_URI);
$client->addScope('email');
$client->addScope('profile');

if (isset($_GET['code'])) {
    $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
    
    if (isset($token['error'])) {
        header('Location: ' . FRONTEND_DOMAIN . '/customer_dashboard.html?auth=error');
        exit;
    }
    
    $client->setAccessToken($token);
    $oauth2 = new Google_Service_Oauth2($client);
    $userInfo = $oauth2->userinfo->get();
    
    // Check if user exists
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "SELECT * FROM users WHERE google_id = :google_id OR email = :email";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':google_id', $userInfo->id);
    $stmt->bindParam(':email', $userInfo->email);
    $stmt->execute();
    $user = $stmt->fetch();
    
    if (!$user) {
        // Create new user
        $username = strtolower(str_replace(' ', '', $userInfo->name)) . rand(100, 999);
        $query = "INSERT INTO users (name, username, email, google_id, role) VALUES (:name, :username, :email, :google_id, 'customer')";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':name', $userInfo->name);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $userInfo->email);
        $stmt->bindParam(':google_id', $userInfo->id);
        $stmt->execute();
        
        $userId = $db->lastInsertId();
        $user = ['id' => $userId, 'name' => $userInfo->name, 'email' => $userInfo->email, 'role' => 'customer'];
    }
    
    // Generate token and redirect
    $token = base64_encode(json_encode(['user_id' => $user['id'], 'role' => $user['role']]));
    
    header('Location: ' . FRONTEND_DOMAIN . '/customer_dashboard.html?auth=success&token=' . $token);
    exit;
} else {
    header('Location: ' . FRONTEND_DOMAIN . '/customer_dashboard.html?auth=error');
    exit;
}
?>

