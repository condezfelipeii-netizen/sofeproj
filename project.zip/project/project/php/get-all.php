<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/response.php';

$database = new Database();
$db = $database->getConnection();

$query = "SELECT * FROM products ORDER BY id ASC";
$stmt = $db->prepare($query);
$stmt->execute();

$products = $stmt->fetchAll();

// Update image paths to full URLs
foreach ($products as &$product) {
    if ($product['image']) {
        // If already a full URL, keep it; otherwise make it relative
        if (!str_starts_with($product['image'], 'http://') && !str_starts_with($product['image'], 'https://')) {
            $product['image'] = '../../assets/images/' . $product['image'];
        }
    }
}

sendResponse(true, 'Products retrieved successfully', $products);
?>

