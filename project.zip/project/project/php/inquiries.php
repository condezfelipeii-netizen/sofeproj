<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/response.php';

$database = new Database();
$db = $database->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Create new inquiry
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['name']) || !isset($data['email'])) {
        sendError('Name and email are required');
    }
    
    $userId = $data['user_id'] ?? null;
    $name = $data['name'];
    $email = $data['email'];
    $phone = $data['phone'] ?? '';
    $eventType = $data['event_type'] ?? '';
    $eventDate = $data['event_date'] ?? null;
    $guestCount = $data['guest_count'] ?? null;
    $location = $data['location'] ?? '';
    $message = $data['message'] ?? '';
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        sendError('Invalid email format');
    }
    
    $query = "INSERT INTO event_inquiries (user_id, name, email, phone, event_type, event_date, guest_count, location, message, status) 
              VALUES (:user_id, :name, :email, :phone, :event_type, :event_date, :guest_count, :location, :message, 'New')";
    $stmt = $db->prepare($query);
    
    $stmt->bindParam(':user_id', $userId);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':event_type', $eventType);
    $stmt->bindParam(':event_date', $eventDate);
    $stmt->bindParam(':guest_count', $guestCount);
    $stmt->bindParam(':location', $location);
    $stmt->bindParam(':message', $message);
    
    if ($stmt->execute()) {
        $inquiryId = $db->lastInsertId();
        
        $query = "SELECT * FROM event_inquiries WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $inquiryId);
        $stmt->execute();
        $inquiry = $stmt->fetch();
        
        sendResponse(true, 'Event inquiry submitted successfully', $inquiry);
    } else {
        sendError('Failed to submit inquiry');
    }
} else {
    // Get inquiries
    $userId = $_GET['user_id'] ?? null;
    $status = $_GET['status'] ?? null;
    
    $query = "SELECT * FROM event_inquiries WHERE 1=1";
    $params = [];
    
    if ($userId !== null) {
        $query .= " AND user_id = :user_id";
        $params[':user_id'] = $userId;
    }
    
    if ($status !== null) {
        $query .= " AND status = :status";
        $params[':status'] = $status;
    }
    
    $query .= " ORDER BY created_at DESC";
    
    $stmt = $db->prepare($query);
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->execute();
    
    $inquiries = $stmt->fetchAll();
    
    sendResponse(true, 'Inquiries retrieved successfully', $inquiries);
}
?>

