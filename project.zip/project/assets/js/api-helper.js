// API Helper Functions
// Provides common functions for making API calls to the backend

const API_BASE_URL = 'http://localhost:8080/project/php';

// Helper function to get auth token
function getAuthToken() {
    return localStorage.getItem('token') || '';
}

// Helper function to get auth headers
function getAuthHeaders() {
    return {
        'Content-Type': 'application/json',
        'Authorization': getAuthToken()
    };
}

// Generic API call function
async function apiCall(endpoint, method = 'GET', data = null, requireAuth = false) {
    const url = API_BASE_URL + endpoint;
    const options = {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        }
    };
    
    // Add auth token if available
    const token = getAuthToken();
    if (token) {
        options.headers['Authorization'] = token;
    }
    
    if (data && (method === 'POST' || method === 'PUT')) {
        options.body = JSON.stringify(data);
    }
    
    try {
        const response = await fetch(url, options);
        const result = await response.json();
        
        if (!response.ok) {
            throw new Error(result.message || 'API request failed');
        }
        
        return result;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Authentication APIs
const AuthAPI = {
    login: async (usernameOrEmail, password, role = null) => {
        // Support both username and email
        const loginData = {
            username: usernameOrEmail,
            password: password
        };
        if (role) loginData.role = role;
        return apiCall('/login.php', 'POST', loginData);
    },
    
    register: async (userData) => {
        return apiCall('/register.php', 'POST', userData);
    },
    
    logout: async () => {
        return apiCall('/logout.php', 'POST');
    },
    
    googleAuth: async () => {
        const result = await apiCall('/google-auth.php', 'GET');
        if (result.success && result.data.auth_url) {
            window.location.href = result.data.auth_url;
        }
    }
};

// Products APIs
const ProductsAPI = {
    getAll: async () => {
        return apiCall('/get-all.php', 'GET');
    },
    
    get: async (id) => {
        return apiCall('/get.php?id=' + id, 'GET');
    },
    
    create: async (productData) => {
        return apiCall('/create.php', 'POST', productData, true);
    },
    
    update: async (id, productData) => {
        return apiCall('/update.php', 'PUT', { id, ...productData }, true);
    },
    
    delete: async (id) => {
        return apiCall('/delete.php?id=' + id, 'DELETE', null, true);
    }
};

// Orders APIs
const OrdersAPI = {
    create: async (orderData) => {
        return apiCall('/create-order.php', 'POST', orderData);
    },
    
    getAll: async (filters = {}) => {
        const queryParams = new URLSearchParams(filters).toString();
        return apiCall('/get-orders.php' + (queryParams ? '?' + queryParams : ''), 'GET');
    },
    
    get: async (id) => {
        return apiCall('/get-order.php?id=' + id, 'GET');
    },
    
    updateStatus: async (id, orderStatus, paymentStatus = null) => {
        return apiCall('/update-status.php', 'POST', {
            id,
            order_status: orderStatus,
            payment_status: paymentStatus
        }, true);
    }
};

// Payments APIs
const PaymentsAPI = {
    createGCash: async (orderId, amount) => {
        return apiCall('/xendit-create.php', 'POST', {
            order_id: orderId,
            amount: amount
        });
    }
};

// Users APIs
const UsersAPI = {
    getProfile: async (id = null) => {
        const endpoint = id ? '/profile.php?user_id=' + id : '/profile.php';
        return apiCall(endpoint, 'GET', null, true);
    },
    
    updateProfile: async (profileData) => {
        return apiCall('/update.php', 'PUT', profileData, true);
    },
    
    submitInquiry: async (inquiryData) => {
        return apiCall('/inquiries.php', 'POST', inquiryData);
    },
    
    getInquiries: async () => {
        return apiCall('/inquiries.php', 'GET', null, true);
    }
};

// Make APIs globally available
if (typeof window !== 'undefined') {
    window.AuthAPI = AuthAPI;
    window.ProductsAPI = ProductsAPI;
    window.OrdersAPI = OrdersAPI;
    window.PaymentsAPI = PaymentsAPI;
    window.UsersAPI = UsersAPI;
    window.API_BASE_URL = API_BASE_URL;
}

